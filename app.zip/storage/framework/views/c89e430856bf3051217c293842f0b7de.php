<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> ©
                <a href="#" class="active">
                    sherifshalaby.tech
                </a>
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    <?php echo e(__('translation.footer_copyright')); ?>

                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\1-projects\2-Sherif-shalaby\mobile-shop\mobile.code.shop\resources\views/layouts/footer.blade.php ENDPATH**/ ?>