
<?php /**PATH /home/mobilegs/public_html/resources/views/layouts/right-sidebar.blade.php ENDPATH**/ ?>