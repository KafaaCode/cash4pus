
<?php /**PATH D:\1-projects\2-Sherif-shalaby\mobile-shop\mobile.code.shop\resources\views/layouts/right-sidebar.blade.php ENDPATH**/ ?>