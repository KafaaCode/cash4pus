
<?php /**PATH D:\work\D-sherif\game-shop\resources\views/layouts/right-sidebar.blade.php ENDPATH**/ ?>